<?php

require 'vendor/autoload.php';
require 'AssertException.php';

define('TESTS_DIR', dirname(__FILE__));
